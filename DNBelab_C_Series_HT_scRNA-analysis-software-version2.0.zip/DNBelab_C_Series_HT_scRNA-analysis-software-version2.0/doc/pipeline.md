# Analysis Workflow

The *dnbc4tools* analysis workflow is designed to integrate various subprogram modules, each of which can independently perform specific tasks. This modular approach allows users to conduct targeted analyses tailored to different research needs.

</br>
</br>


## Single-Cell RNA Analysis ([English](./pipeline/scRNA_en.md) | [中文](./pipeline/scRNA.md))

</br>
</br>


## Single-Cell ATAC Analysis ([English](./pipeline/scATAC_en.md) | [中文](./pipeline/scATAC.md))

</br>
</br>


## Single-Cell VDJ Analysis ([English](./pipeline/scVDJ_en.md) | [中文](./pipeline/scVDJ.md))

</br>
</br>

## Parameter of dnbc4tools ([English](./parameter/parameter_en.md) | [中文](./parameter/parameter.md))